require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const User = require('./models/User');
const logger = require('./middleware/logger');

const app = express();
const PORT = process.env.PORT || 5000;

app.use(express.json());
app.use(logger);

mongoose.connect(process.env.MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('MongoDB connected'))
  .catch(err => console.error('MongoDB connection error:', err));

// POST /users - Create user
app.post('/users', async (req, res) => {
  try {
    const { name, email, age, isActive } = req.body;
    if (!name || !email) return res.status(400).json({ error: 'Name and email are required.' });

    const user = new User({ name, email, age, isActive });
    await user.save();
    res.status(201).json(user);
  } catch (err) {
    if (err.name === 'ValidationError') return res.status(400).json({ error: err.message });
    if (err.code === 11000) return res.status(400).json({ error: 'Email must be unique.' });
    res.status(500).json({ error: 'Server error' });
  }
});

// GET /users - List users with pagination, filtering, sorting
app.get('/users', async (req, res) => {
  try {
    const { page = 1, limit = 10, sortBy = 'createdAt', order = 'desc', name, age } = req.query;

    const filter = {};
    if (name) filter.name = new RegExp(name, 'i');
    if (age) filter.age = Number(age);

    const users = await User.find(filter)
      .sort({ [sortBy]: order === 'desc' ? -1 : 1 })
      .skip((page - 1) * limit)
      .limit(Number(limit));

    const total = await User.countDocuments(filter);

    res.json({ page: Number(page), limit: Number(limit), total, users });
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

// GET /users/:id - Get user by ID
app.get('/users/:id', async (req, res) => {
  try {
    const user = await User.findById(req.params.id);
    if (!user) return res.status(404).json({ error: 'User not found.' });
    res.json(user);
  } catch (err) {
    res.status(400).json({ error: 'Invalid user ID.' });
  }
});

// PUT /users/:id - Update user by ID
app.put('/users/:id', async (req, res) => {
  try {
    const { name, email, age, isActive } = req.body;
    if (!name || !email) return res.status(400).json({ error: 'Name and email are required.' });

    const user = await User.findByIdAndUpdate(
      req.params.id,
      { name, email, age, isActive },
      { new: true, runValidators: true, context: 'query' }
    );

    if (!user) return res.status(404).json({ error: 'User not found.' });
    res.json(user);
  } catch (err) {
    if (err.name === 'ValidationError') return res.status(400).json({ error: err.message });
    if (err.code === 11000) return res.status(400).json({ error: 'Email must be unique.' });
    res.status(400).json({ error: 'Invalid request.' });
  }
});

// DELETE /users/:id - Delete user by ID
app.delete('/users/:id', async (req, res) => {
  try {
    const user = await User.findByIdAndDelete(req.params.id);
    if (!user) return res.status(404).json({ error: 'User not found.' });
    res.json({ message: 'User deleted successfully.' });
  } catch (err) {
    res.status(400).json({ error: 'Invalid user ID.' });
  }
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});

